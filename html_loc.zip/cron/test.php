<?
	
	//$link 	= mysqli_connect("localhost", "root", "password.1", "doe");
	//$sql  	= "insert into test values('aa')";
	//$dt	  	= mysqli_query($link, $sql) ;
	//if ($dt){
	//	echo "sukses";
	//}else{ echo "failed";}
?>