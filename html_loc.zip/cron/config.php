<?php
	date_default_timezone_set('Asia/Jakarta');
	$hostname 	= 'localhost';
	$username 	= 'root';
	$password 	= 'password.1';	
	$dbname		= 'doe';
	
?>