<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class wip_child1 extends Model
{
    protected $table = 'wip_child1_vd';
}
