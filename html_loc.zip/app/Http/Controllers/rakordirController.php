<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;

class rakordirController extends Controller
{
   public function __construct ()
	{
	   date_default_timezone_set('Asia/Jakarta');
    }
    public function index(Request $request)
    {
    	$data_group     = $request->get('data_group');
        $data_menu      = $request->get('data_menu');
    	return view('rakordir.inputFile',
  			[
  				'data_group'    =>$data_group,
  				'data_menu'     =>$data_menu
  			]);
    }
    public function upload(Request $request)
    {
    	$validator = Validator::make($request->all(), [
            'file' => 'required|mimes:pdf,PDF',
        ]);

        if ($validator->fails()) {
        	$errors = $validator->errors();

            $path =  response()->json( $errors->first('file') , 400);
        }else{
        	$uploadedFile = $request->file('file');        
        	$path = $uploadedFile->storeAs('public');
        	$realName = $request->file->getClientOriginalName();
        }

        

        return $path;
    }
}
