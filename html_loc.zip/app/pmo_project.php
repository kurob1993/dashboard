<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pmo_project extends Model
{
    protected $table = 'pmo_project';
}
