<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pmo_project_budget extends Model
{
    protected $table = 'pmo_project_budget';
}
