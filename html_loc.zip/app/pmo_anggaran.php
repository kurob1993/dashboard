<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pmo_anggaran extends Model
{
   protected $table = 'pmo_anggaran';
}
