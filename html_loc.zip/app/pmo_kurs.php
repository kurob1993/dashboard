<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pmo_kurs extends Model
{
    protected $table = 'pmo_kurs';
}
